﻿function windowClose() 
{
    window.open('', '_parent', '');
    window.close();
}