﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PropertyLayer
{
    public class PL_MasterBarcodePrinting
    {

        public string strCode { set; get; }
        public string strModule { set; get; }
        public string strReson { set; get; }
        public string strUser { set; get; }
        
    }
}
