﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PropertyLayer
{
    public class PL_STR_WeighingCalibration
    {


        public string strWeighID { get; set; }
        public string strUsername { get; set; }
        public string strPlantCode { get; set; }
        public string strStdWeightOnScale { get; set; }
        public string strAccureacyLmt { get; set; }
        public string strWt { get; set; }
        public string strCubicle { get; set; }

    }
}
