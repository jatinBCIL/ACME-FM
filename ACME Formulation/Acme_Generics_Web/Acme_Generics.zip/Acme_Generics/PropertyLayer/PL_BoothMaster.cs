﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PropertyLayer
{
    public class PL_BoothMaster
    {
        public string strPlantCode { get; set; }
        public string strBoothCode { get; set; }
        public string strBoothDesc { get; set; }
        public string strStorageLocation { get; set; }
        public string strCreatedBy { get; set; }
        public string strMODE { get; set; }
        public string strRemark { get; set; }
        public int intStatus { get; set; }
        public int REFNO { get; set; }

    }
}
