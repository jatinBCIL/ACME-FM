﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PropertyLayer
{
    public class PL_BinMaster
    {
        public string strPlantCode { get; set; }
        public string strLocationID { get; set; }
        public string strLocationName { get; set; }
        public string strWarehouseType { get; set; }
        public string strCreatedBy { get; set; }
        public string strMODE { get; set; }
        public string strRemark { get; set; }
        public int intStatus { get; set; }
        public int REFNO { get; set; }

    }
}
