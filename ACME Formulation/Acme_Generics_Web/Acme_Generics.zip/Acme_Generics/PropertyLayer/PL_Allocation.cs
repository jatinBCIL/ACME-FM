﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PropertyLayer
{
   public class PL_Allocation
    {
        public string strPlantCode { get; set; }
        public string strMaterialCode { get; set; }
        public string strSAPBatch { get; set; }
        public int iQty { get; set; }
        public string strBin { get; set; }
        public string strBarcode { get; set; }
        public string strUsername { get; set; }

        
    }
}
