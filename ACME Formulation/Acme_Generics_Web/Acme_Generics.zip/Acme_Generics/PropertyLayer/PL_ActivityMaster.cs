﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PropertyLayer
{
    public class PL_ActivityMaster
    {
        public string strplantcode {set; get;  }
        public string strActivityCode{set; get;}   
        public string strActivityname{set; get;}   
                                                   
         public string strActivitStatus{set; get;}  
         public string strActivityStatusAfterStop{set; get;}  
         public string strActivityStart{set; get;}  
         public string strActivityStartCheck{set; get;}  
         public string strActivityContinue{set; get;}  
         public string strActivityContinueCheck{set; get;}  
         public string strActivityStop{set; get;}  
         public string strActivityStopCheck{set; get;}  
         public int intStatus{set; get;}  
         public string user{set; get;}  
         public string strMode{set; get;}
         public string strRemark { set; get; }


    }
}
