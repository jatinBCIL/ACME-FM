﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PropertyLayer
{
    public class Pl_recipeExcelFor
    {

         public string strUsername { set; get; }
       public string strPlant { set; get; }
       public string strPlantType { set; get;  }
      
    }
}
